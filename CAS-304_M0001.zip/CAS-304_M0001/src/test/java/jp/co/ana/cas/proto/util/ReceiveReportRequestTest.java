package jp.co.ana.cas.proto.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;

import java.io.StringWriter;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.log4j.LogManager;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.WriterAppender;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.reflect.Whitebox;

@PrepareForTest({ ReceiveReportRequest.class })
class ReceiveReportRequestTest {
	@Mock
	Connection conn;

	@Mock
	Session session;

	@Mock
	Destination destination;

	@Mock
	MessageConsumer msgConsumer;

	@Mock
	Message reserveMsg;

	@Mock
	TextMessage textMsg;

	@Mock
	OutputReport outputReport;

	@InjectMocks
	ReceiveReportRequest rsvReq = new ReceiveReportRequest();


	public static final String LogFileName = "Junit.log";
	public static final String junitTest = "[JunitTest]";
	public static final String className = "ReceiveReportRequest";
	public static final String OK = "OK";
	public static final String NG = "NG";
	public static final String TEST_ENDPOINT = "ssl://test:9999";
	String logMsg = "";
	int testNum = 1;
	private String format = "%s,%s,%d,%s";

	@BeforeEach
	public void initEachTest() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testReportCreateMain() {
		//ANA予約番号取り出し結果がNull
		String methodName = "reportCreateMain";
		String itemContent = "ANA予約番号がNULLであること、ログに\"帳票作成処理完了\"と表示されないことを確認";

		ReceiveReportRequest rsvReqSpy = spy(rsvReq);
		// モック戻り値の設定
		String receiveMsg = null;
		Whitebox.setInternalState(rsvReqSpy, "mqEndpoint", TEST_ENDPOINT);
//		ActiveMQConnectionFactory testFactory = new ActiveMQConnectionFactory(TEST_ENDPOINT);

		StringWriter writer = new StringWriter();
		WriterAppender appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);

		try {
			doNothing().when(rsvReqSpy).openConnection(any());
			doReturn(receiveMsg).when(rsvReqSpy).getReportRequest();
			rsvReqSpy.reportCreateMain();
			String logString = writer.toString();
			assertFalse(logString.contains("帳票作成処理完了"));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}
		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;

		//ANA予約番号取り出し結果がNullではない
		itemContent = "ANA予約番号がNULLでないこと、ログに\"帳票作成処理完了\"が表示されることを確認";
		receiveMsg = "<printingDTO><applicationDataDTO><pnrRecordLocator>123456</pnrRecordLocator></applicationDataDTO></printingDTO>";

		doReturn(receiveMsg).when(rsvReqSpy).getReportRequest();
		doNothing().when(outputReport).outputReportMain(anyString());

		writer = new StringWriter();
		appender = new WriterAppender(new PatternLayout("%p,%m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);

		try {
			rsvReqSpy.reportCreateMain();
			String logString = writer.toString();
			assertTrue(logString.contains("帳票作成処理完了"));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}
		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;
	}

	@Test
	public void testGetReportRequest() {
		String methodName = "getReportRequest";
		String itemContent = "Amazon MQに接続できること、帳票作成要求が存在しないことを確認";

		try {
			doReturn(msgConsumer).when(session).createConsumer(any());
		} catch (JMSException e) {
			e.printStackTrace();
		}

		String result = rsvReq.getReportRequest();
		assertNull(result);
		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;

		itemContent = "Amazon MQから帳票作成要求を取得することを確認";
		String msg="<printingDTO><applicationDataDTO><pnrRecordLocator>123456</pnrRecordLocator></applicationDataDTO></printingDTO>";

		try {
			doReturn(msgConsumer).when(session).createConsumer(any());
			doReturn((Message) textMsg).when(msgConsumer).receive(1000);
			doReturn(msg).when(textMsg).getText();
		} catch (JMSException e) {
			e.printStackTrace();
		}

		result = rsvReq.getReportRequest();
		String expected = "<printingDTO><applicationDataDTO><pnrRecordLocator>123456</pnrRecordLocator></applicationDataDTO></printingDTO>";
		assertEquals(expected, result);
		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;
	}

	@Test
	public void testOpenConnection() {

		ReceiveReportRequest rsvReqSpy = spy(rsvReq);
		Whitebox.setInternalState(rsvReqSpy, "mqEndpoint", TEST_ENDPOINT);
		ActiveMQConnectionFactory testFactory = PowerMockito.mock(ActiveMQConnectionFactory.class);

		try {
			doReturn(conn).when(testFactory).createConnection();
			doNothing().when(conn).start();
			doReturn(session).when(conn).createSession(anyBoolean(), anyInt());
			doReturn(msgConsumer).when(session).createConsumer(destination);
			rsvReqSpy.openConnection(testFactory);
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testCloseConnection() throws Exception {
		rsvReq.closeConnection();
	}

	@Test
	public void testCloseConnectionAlreadyClose() throws Exception {
		new ReceiveReportRequest().closeConnection();
	}

	@Test
	public void testExtractReserveNum() {
		String methodName = "extractReserveNum";
		//Amazon MQから帳票作成要求を取得すること
		String itemContent = "帳票作成要求から予約番号を取り出せることを確認";
		String argument = "<printingDTO><applicationDataDTO><pnrRecordLocator>123456</pnrRecordLocator></applicationDataDTO></printingDTO>";
		ReceiveReportRequest reReportRequest = new ReceiveReportRequest();
		String result = reReportRequest.extractReserveNum(argument);
		String expected = "123456";
		assertEquals(expected, result);
		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;

		//ANA予約番号が6文字以外
		itemContent = "返却値がNullであること(予約番号が6文字以外)を確認";
		argument = "<printingDTO><applicationDataDTO><pnrRecordLocator>1234</pnrRecordLocator></applicationDataDTO></printingDTO>";
		result = reReportRequest.extractReserveNum(argument);
		assertNull(result);
		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;
		//ANA予約番号がNull
		itemContent = "返却値がNullであること(予約番号が無し)を確認";
		argument = "<printingDTO><applicationDataDTO><pnrRecordLocator></pnrRecordLocator></applicationDataDTO></printingDTO>";
		result = reReportRequest.extractReserveNum(argument);
		assertNull(result);
		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;
	}

	/**
	 * 異常系.
	 */
	@Test
	public void testAnomalyGetReportRequest() throws Exception {
		String methodName = "getReportRequest";
		String itemContent = "Amazon MQの接続に失敗することを確認";

		ReceiveReportRequest rsvReqSpy = spy(rsvReq);

		ActiveMQConnectionFactory factoryMock = PowerMockito.mock(ActiveMQConnectionFactory.class);
		ActiveMQConnectionFactory testFactory = new ActiveMQConnectionFactory(TEST_ENDPOINT);

		doThrow(JMSException.class).when(factoryMock).createConnection();

		StringWriter writer = new StringWriter();
		WriterAppender appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);

		try {
			rsvReqSpy.openConnection(testFactory);
			String logString = writer.toString();
			assertTrue(logString.contains("MQ Connect ERROR."));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}

		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;
	}

	@Test
	public void testAnomalyExtractReserveNum() {
		String methodName = "extractReserveNum";
		String itemContent = "xml変換に失敗することを確認";
		String argument = "<test1><test2></test1></test2>";
		ReceiveReportRequest reReportRequest = new ReceiveReportRequest();

		StringWriter writer = new StringWriter();
		WriterAppender appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);

		try {
			reReportRequest.extractReserveNum(argument);
			String logString = writer.toString();
			assertTrue(logString.contains("帳票作成要求不正"));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}

		logMsg = String.format(format, className, methodName, testNum, itemContent);
		OutputLog.outputLogMessage(OutputLog.INFO, logMsg);
		testNum++;
	}
}