package jp.co.ana.cas.proto.giji;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;
//import org.springframework.boot.SpringApplication;

public class MsgProducer {
	public static void main(String[] args) {
//		SpringApplication.run(MessageProducerApplication.class, args);

//		MsgProducer msgPro = new MsgProducer();
//		msgPro.sendMsg();
	}

	public void sendMsg() {

		String wireLevelEndpoint = "ssl://b-b09d16cd-21f5-440e-bfc3-96decadfa911-1.mq.ap-northeast-1.amazonaws.com:61617";
		String activeMqUsername = "CAS_Prototype";
		String activeMqPassword = "CAS_Prototype";

		// Create a connection factory.
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(wireLevelEndpoint);

		// Pass the username and password.
		connectionFactory.setUserName(activeMqUsername);
		connectionFactory.setPassword(activeMqPassword);

		// Create a pooled connection factory.
		PooledConnectionFactory pooledConnectionFactory = new PooledConnectionFactory();
		pooledConnectionFactory.setConnectionFactory(connectionFactory);
		pooledConnectionFactory.setMaxConnections(10);

		// Establish a connection for the producer.
		try {
			Connection producerConnection = pooledConnectionFactory.createConnection();
			producerConnection.start();

			// Create a session.
			Session producerSession = producerConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);

			// Create a queue named "MyQueue".
			Destination producerDestination = producerSession.createQueue("cas-report");

			// Create a producer from the session to the queue.
			MessageProducer producer = producerSession.createProducer(producerDestination);
			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

			// Create a message.
			String text = "<printingDTO><applicationDataDTO><pnrRecordLocator>123456</pnrRecordLocator></applicationDataDTO></printingDTO>";
			TextMessage producerMessage = producerSession.createTextMessage(text);

			// Send the message.
			producer.send(producerMessage);
			System.out.println("Message sent.");

			producer.close();
			producerSession.close();
			producerConnection.close();

		} catch (JMSException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}
}
