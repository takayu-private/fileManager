package jp.co.ana.cas.proto.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.reflect.Whitebox;

import jp.co.ana.cas.proto.dao.ReportListDao;
import jp.co.ana.cas.proto.dto.ReportListDto;

public class OutputReportTest{
	public static final String LogFileName = "CAS-304_M0001//CAS-304_M0001\\Junit.log";
	public static final String junitTest = "[JunitTest]";
	public static final String  CLASS = "OutputReport";
	public static final String SVF_HOST = "52.193.176.86";
	public static final String DRIVER_URL = "jdbc:postgresql://18.182.8.188:5432/postgres";
	public static final String DB_USER = "postgres";
	public static final String DB_PASSWD = "postgres";
	public static final String INSERT_SQL = "INSERT INTO report_strage.report_list (file_name,file_data) values(?,?);";

	@Mock
	HttpURLConnection urlConn;
	@Mock
	PrintStream ps;
	@Mock
	BufferedReader reader;
	@Mock
	Connection dbConn;
	@Mock
	ReportListDao reportListDao;
	
	@InjectMocks
	OutputReport outputReport = new OutputReport();

	// モックの初期化
	@BeforeEach
 	public void initEachTest() {
		MockitoAnnotations.initMocks(this);
 	}

	// 環境変数の設定(のつもりで内部変数に直接設定
	@BeforeEach
	public void setenv() {
		Whitebox.setInternalState(outputReport, "protocol", "http");
		Whitebox.setInternalState(outputReport, "svfHost", SVF_HOST);
		Whitebox.setInternalState(outputReport, "svfPortstr", "23456");
		Whitebox.setInternalState(outputReport, "filePath", "FilePath");
		Whitebox.setInternalState(outputReport, "httpMethod", "GET");
	}
	
	// 試験用のURL作成処理
	public URL createTestURL(int responseCode) throws UnsupportedEncodingException, IOException {
		HttpURLConnection huc = PowerMockito.mock(HttpURLConnection.class);
		when(huc.getResponseCode()).thenReturn(responseCode);

		InputStream in = new ByteArrayInputStream("test".getBytes("utf-8"));
		when(huc.getInputStream()).thenReturn(in);

		OutputStream out = new ByteArrayOutputStream();
		when(huc.getOutputStream()).thenReturn(out);

		URLStreamHandler stubUrlHandler = new URLStreamHandler() {
			@Override
			protected URLConnection openConnection(URL u) throws IOException {
				return huc;
			}
		};

		return new URL("http", "dummyhost", 9999, "/data.json", stubUrlHandler);
	}

	
	@Test
	public void outputReportMain_OK() throws IOException, SQLException {
		OutputReport or = spy(outputReport);
		doNothing().when(or).openConnection(any());
		doReturn("1234567").when(or).outputReportRequest(anyString());
		doNothing().when(or).insertReport(anyString(), anyString());

		ReserveInformation reserveInfo = spy(new ReserveInformation());

		Whitebox.setInternalState(reserveInfo, "protocol", "http");
		Whitebox.setInternalState(reserveInfo, "alteaHost", "dummy");
		Whitebox.setInternalState(reserveInfo, "alteaPort", 9999);
		Whitebox.setInternalState(reserveInfo, "filePath", "./file");
		Whitebox.setInternalState(reserveInfo, "httpMethod", "GET");
		doReturn("Reserve_Information_1234567").when(reserveInfo).createReserveInformationRequest(anyString());
		doNothing().when(reserveInfo).openConnection(any());
		doReturn("1234567").when(reserveInfo).getReserveInformationRequest(anyString());

		Whitebox.setInternalState(or, "reserveInfo", reserveInfo);

		or.outputReportMain("345678");
	}

	@Test
	public void openConnection()  throws UnsupportedEncodingException, IOException {
		URL url = createTestURL(200);
		new OutputReport().openConnection(url);
	}

	@Test
	public void closeConnection_OK() throws Exception {
		outputReport.closeConnection();
	}

	@Test
	public void closeConnection_AlreadyCloseCase() throws Exception {
		new OutputReport().closeConnection();
	}


	@Test
	public void outputReport_OK() throws IOException {
		// モック戻り値の設定
		doReturn(200).when(urlConn).getResponseCode();
		doReturn("test<soapenv:Envelope>test<soapenv:Header>test</soapenv:Header><soapenv:Body>",
				  "<reserveDetails><reserveInformation>Reserve_", "Information_1234567</reserveInformation>",
				  "</reserveDetails></soapenv:Body></soapenv:Envelope>",
				  null).when(reader).readLine();
		outputReport.outputReportRequest("csvReserveInfo");
	}

	@Test
	public void insertReport_OK() throws SQLException, ClassNotFoundException {
		doNothing().when(reportListDao).insertReportToDB(any());
		
		String reserveNum = "123456";
		String testReportFile = "testtesttesttest";
		
		outputReport.insertReport(reserveNum, testReportFile);
		
		ReportListDto reportDto = Whitebox.getInternalState(outputReport, "reportDto");
		
		String testReportName = "report_" + reserveNum + ".pdf";
		assertEquals(testReportName, reportDto.getReportName());
		assertEquals(testReportFile, reportDto.getReportData());
	}
}