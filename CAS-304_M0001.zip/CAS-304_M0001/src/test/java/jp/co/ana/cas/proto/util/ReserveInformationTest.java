package jp.co.ana.cas.proto.util;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import mockit.Deencapsulation;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;

import util.OutputLog;
import util.ReserveInformation;


public class ReserveInformationTest {

	public static final String LogFileName = "CAS-304_M0001//CAS-304_M0001//Junit.log";
	public static final String junitTest = "[JunitTest]";
 	public static final String  CLASS = "ReserveInformation";
//	@Test
//	public void test() {
//		renameLogFile();
//
//		getReserveInformation_test();
//		createReserveInformationRequest_test();
//		getReserveInformationRequest_test();
//		getReserveInformationRequest_NG_test();
//		extractValue_test();
//		createCreated_test();
//		createCreatedHex_test();
//		createNonceHex_test();
//		createNonce_test();
//		createPasswdSha_test();
//		createPasswd_test();
//		wsSecurity_test();
//	}


//	@Test
	public void getReserveInformation_test() {
		String method = "getReserveInformation";
		int number = 1;

		ReserveInformation rsvinfo = new ReserveInformation();
		String responseMsg =rsvinfo.getReserveInformation("12345");

		String expected = "Reserve_Information_1234567";
		assertEquals(expected, responseMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得することを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+responseMsg);
	}

	@Test
	public void extractValue_test() {
		String method = "extractValue";
		int number = 1;


		ReserveInformation rsvinfo = new ReserveInformation();
		//rsvinfo.extractValue();
		String responseMsg = "test<soapenv:Envelope>test<soapenv:Header>test</soapenv:Header><soapenv:Body><reserveDetails><reserveInformation>test_reserveInformation_123</reserveInformation></reserveDetails></soapenv:Body></soapenv:Envelope>";
		String testValue = rsvinfo.extractValue(responseMsg, ReserveInformation.TAG_SOAP_ENVELOPE);
		String expected = "test<soapenv:Header>test</soapenv:Header><soapenv:Body><reserveDetails><reserveInformation>test_reserveInformation_123</reserveInformation></reserveDetails></soapenv:Body>";
		assertEquals(expected, testValue);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", soapenv:Envelopeの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue(testValue, ReserveInformation.TAG_SOAP_BODY);
		expected = "<reserveDetails><reserveInformation>test_reserveInformation_123</reserveInformation></reserveDetails>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", soapenv:Bodyの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);


		testValue = rsvinfo.extractValue(testValue, ReserveInformation.TAG_RESERVE_DETAIL);
		expected = "<reserveInformation>test_reserveInformation_123</reserveInformation>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", reserveDetailsの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);


		testValue = rsvinfo.extractValue(testValue, ReserveInformation.TAG_RESERVE_INFO);
		expected = "test_reserveInformation_123";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", reserveInformationの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);


		testValue = rsvinfo.extractValue(null, ReserveInformation.TAG_RESERVE_INFO);
		assertNull(testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", 第一引数がnullの場合、nullを返すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue("<reserveInformation>test_reserveInformation_123</reserveInformation>", null);
		expected = "<reserveInformation>test_reserveInformation_123</reserveInformation>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", 第二引数がnullの場合、第一引数を返すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue("<reserveInformation>test_reserveInformation_123</reserveInformation>", "dummytag");
		expected = "<reserveInformation>test_reserveInformation_123</reserveInformation>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", 第一引数の文字列の中にtagが存在しない場合、第一引数を返すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

	}



	@Test
	public void wsSecurity_test() {
		String method = "wsSecurity";
		int number = 1;

		ReserveInformation rsvinfo = new ReserveInformation();

		HashMap<String, String> testHash = rsvinfo.wsSecurity();

		assertNotNull(testHash.get("Created"));
        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Createdの値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testHash.get("Created"));

		assertNotNull(testHash.get("Nonce"));
        ut = junitTest+","+ CLASS+","+method+","+(number++)+", Nonceの値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testHash.get("Nonce"));

		assertNotNull(testHash.get("Password"));
        ut = junitTest+","+ CLASS+","+method+","+(number++)+", Passwordの値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testHash.get("Password"));
	}


//	@Test
	public void createPasswd_test() {
		String method = "createPasswd";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		long Epoch = date.getTime();

		ReserveInformation rsvinfo = new ReserveInformation();
		//Created
		String created = rsvinfo.createCreated(Epoch);
		String createdHex = rsvinfo.createCreatedHex(created);
		//Nonce
		String noceHex = rsvinfo.createNonceHex(Epoch);
		String nonce = rsvinfo.createNonce(noceHex);
		//password
		String passwdSha = rsvinfo.createPasswdSha();
		String passwd = rsvinfo.createPasswd(noceHex, createdHex, passwdSha);

		String expected = "C3160D7F0030A1A71194DF29D2DBB16D38620DE0";
//		assertEquals(expected, passwd);
//        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", NonceとCreatedとPasswordのハッシュ値をBase64エンコードした値が生成されることを確認";
//		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+passwd);
	}

//	@Test
	public void createNonce_test() {
		String method = "createNonce";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		long Epoch = date.getTime();

		ReserveInformation rsvinfo = new ReserveInformation();
		String noceHex = rsvinfo.createNonceHex(Epoch);
		String nonce = rsvinfo.createNonce(noceHex);
		String expected = "TqNLTKpSlKrr+WWbghe+jA==";
//		assertEquals(expected, nonce);
//        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", NonceをBase64エンコードした値が生成されることを確認";
//		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+nonce);
	}

//	@Test
	public void createNonceHex_test() {
		String method = "createNonceHex";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		long Epoch = date.getTime();
		System.out.println("Epoch_nc: "+Epoch);

		ReserveInformation rsvinfo = new ReserveInformation();
		String noceHex = rsvinfo.createNonceHex(Epoch);
		String expected = "4EA34B4CAA5294AAEBF9659B8217BE8C";
//		assertEquals(expected, noceHex);
//        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", CreatedをHEX変換した値が生成されることを確認";
//		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+noceHex);
	}


//	@Test
	public void createCreatedHex_test() {
		String method = "createCreatedHex";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		long Epoch = date.getTime();

		ReserveInformation rsvinfo = new ReserveInformation();
		String created = rsvinfo.createCreated(Epoch);
		String createdHex = rsvinfo.createCreatedHex(created);
		String expected = "323032302d30332d31365430383a31383a31312e3032395a";
		assertEquals(expected, createdHex);
        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", CreatedをHEX変換した値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+createdHex);
	}

//	@Test
	public void createCreated_test() {
		String method = "createCreated";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		long Epoch = date.getTime();
System.out.println("Epoch_cr: "+Epoch);

		ReserveInformation rsvinfo = new ReserveInformation();
		String created = rsvinfo.createCreated(Epoch);
		String expected = dateStr;
		assertEquals(expected, created);
        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", 時刻情報からCreatedが生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+created);
	}


//	@Test
	public void createPasswdSha_test() {
		String method = "createPasswdSha";
		int number = 1;

		ReserveInformation rsvinfo = new ReserveInformation();
		String passSha = rsvinfo.createPasswdSha();
		String expected = "4243f3ff732f14a562aca4cb6d837cc05726055d";
		assertEquals(expected, passSha);
        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", AlteaのパスワードからSHA-1のメッセージダイジェストが生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+passSha);
	}


//	@Test
	public void createReserveInformationRequest_test() {
		String method = "createReserveInformationRequest";
		int number = 1;

        Random random = new Random();
        int randomValue = random.nextInt(1000000);

        String reserveNum = String.format("%06d", randomValue);
        System.out.println("reserveNum: "+reserveNum);

		ReserveInformation rsvinfo = new ReserveInformation();
		String requestMsg = rsvinfo.createReserveInformationRequest(reserveNum);

		assertNotNull(requestMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", 予約情報取得要求を作成することを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +",requestMsg:"+requestMsg);

	}

//	@Test
	public void getReserveInformationRequest_test() {
		String method = "getReserveInformationRequest";
		int number = 1;

        Random random = new Random();
        int randomValue = random.nextInt(1000000);

        String reserveNum = String.format("%06d", randomValue);
        System.out.println("reserveNum: "+reserveNum);

		ReserveInformation rsvinfo = new ReserveInformation();
//		SOAPMessage requestMsg = rsvinfo.createReserveInformationRequest(reserveNum);

		String responseMsg = rsvinfo.getReserveInformationRequest("aaaaa,bbbb,cccc");

		String expected = "Reserve_Information_1234567";
		assertEquals(expected, responseMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得することを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+responseMsg);

		renameLogFile();
	}

//	@Test
	public void getReserveInformationRequest_NG_test() {
		String method = "getReserveInformationRequest";
		int number = 2;

        Random random = new Random();
        int randomValue = random.nextInt(1000000);

        String reserveNum = String.format("%06d", randomValue);
        System.out.println("reserveNum: "+reserveNum);

		ReserveInformation rsvinfo = new ReserveInformation();
//		SOAPMessage requestMsg = rsvinfo.createReserveInformationRequest(reserveNum);

		String responseMsg = rsvinfo.getReserveInformationRequest("aaaaa,bbbb,cccc");

		Deencapsulation.setField(ReserveInformation.class, "ALTEA_URL", "http://xxxxx/xxxxx");

		assertNull(responseMsg);
		assertTrue(getLog("Altea IO ERROR.").length() != 0);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaとの接続失敗時、予約情報を取得できないことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+responseMsg);

	}

	public void renameLogFile() {
		Calendar cl = Calendar.getInstance();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        System.out.println(sdf.format(cl.getTime()));

        try {
        	Path srcPath = Paths.get(LogFileName);
        	Path trgPath = Paths.get(LogFileName+"_"+sdf.format(cl.getTime()));

			Files.move(srcPath, trgPath);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			//e.printStackTrace();
		}
	}

	public String getLog(String msg) {

        List<String> lines = new ArrayList<String>();
        try {
        	Path path = Paths.get(LogFileName);
            lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(int counter = lines.size()-1;  counter >= 0; --counter ) {
        	if(lines.get(counter).indexOf(msg)!= -1) {
        		return lines.get(counter);
        	}
        }
        return "";
	}

}
