package jp.co.ana.cas.proto.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.TimeZone;

import org.apache.log4j.LogManager;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.WriterAppender;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.reflect.Whitebox;

@PrepareForTest({ URL.class, ReserveInformation.class })
public class ReserveInformationTest {
	@Mock
	HttpURLConnection urlConn;

	@Mock
	PrintStream ps;

	@Mock
	BufferedReader reader;

	@InjectMocks
	ReserveInformation rsvinfo = new ReserveInformation();

	public static final Path confPath = Paths.get("src/test/resources/");
	public static final String LogFileName = "CAS-304_M0001//CAS-304_M0001//Junit.log";
	public static final String junitTest = "[JunitTest]";
	public static final String  CLASS = "ReserveInformation";

	@BeforeEach
	public void initEachTest() {
		MockitoAnnotations.initMocks(this);
	}

	// 試験用のURL作成処理
	public URL createTestURL(int responseCode, String responsMsg) throws Exception {
		String resMsg;
		if(responsMsg.equals("")) {
			resMsg = "test";
		} else {
			resMsg = responsMsg;
		}
		HttpURLConnection huc = PowerMockito.mock(HttpURLConnection.class);
		when(huc.getResponseCode()).thenReturn(responseCode);

		InputStream in = new ByteArrayInputStream(resMsg.getBytes("utf-8"));
		when(huc.getInputStream()).thenReturn(in);

		OutputStream out = new ByteArrayOutputStream();
		when(huc.getOutputStream()).thenReturn(out);

		URLStreamHandler stubUrlHandler = new URLStreamHandler() {
			@Override
			protected URLConnection openConnection(URL u) throws IOException {
				return huc;
			}
		};

		return new URL("http", "dummyhost", 9999, "/data.json", stubUrlHandler);
	}

//	@Test
	public void openConnection() throws Exception {
		URL url = createTestURL(200, "");
		new ReserveInformation().openConnection(url);
	}


	@Test
	public void getReserveInformation_resp200_1() throws Exception {
		String method = "getReserveInformation";
		int number = 1;

		ReserveInformation rsvinfo2 = spy(rsvinfo);

		Whitebox.setInternalState(rsvinfo2, "protocol", "http");
		Whitebox.setInternalState(rsvinfo2, "alteaHost", "dummy");
		Whitebox.setInternalState(rsvinfo2, "alteaPort", 9999);
		Whitebox.setInternalState(rsvinfo2, "filePath", "./file");
		Whitebox.setInternalState(rsvinfo2, "httpMethod", "GET");

		String resMsg = "<soapenv:Envelope><soapenv:Header>test</soapenv:Header>" +
				"<soapenv:Body><reserveDetails><reserveInformation>" +
				"Reserve_Information_1234567</reserveInformation>" +
				"</reserveDetails></soapenv:Body></soapenv:Envelope>";
		URL url = createTestURL(200, resMsg);
		rsvinfo2.openConnection(url);

		String requestMsg = rsvinfo2.createReserveInformationRequest("123456");
		assertNotNull(requestMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaへのリクエストメッセージが作成されること";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);

		String responseMsg = rsvinfo2.getReserveInformationRequest("123456");
		String expected = "Reserve_Information_1234567";
		assertEquals(expected, responseMsg);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得することを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);
	}

	@Test
	public void getReserveInformation_resp200_2() throws Exception {
		String method = "getReserveInformation";
		int number = 1;

		ReserveInformation rsvinfo2 = spy(rsvinfo);

		Whitebox.setInternalState(rsvinfo2, "protocol", "http");
		Whitebox.setInternalState(rsvinfo2, "alteaHost", "dummy");
		Whitebox.setInternalState(rsvinfo2, "alteaPort", 9999);
		Whitebox.setInternalState(rsvinfo2, "filePath", "./file");
		Whitebox.setInternalState(rsvinfo2, "httpMethod", "GET");

		URL url = createTestURL(200, "");
		rsvinfo2.openConnection(url);
		String reqMsg = rsvinfo2.createReserveInformationRequest(anyString());
		doReturn("Reserve_Information_1234567").when(rsvinfo2).getReserveInformationRequest(anyString());
		String responseMsg = rsvinfo2.getReserveInformationRequest(reqMsg);
		String expected = "Reserve_Information_1234567";

		assertEquals(expected, responseMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得することを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);
	}

	@Test
	public void getReserveInformation_resp200_3() throws Exception {
		String method = "getReserveInformation";
		int number = 1;

		ReserveInformation rsvinfo2 = spy(rsvinfo);

		Whitebox.setInternalState(rsvinfo2, "protocol", "http");
		Whitebox.setInternalState(rsvinfo2, "alteaHost", "dummy");
		Whitebox.setInternalState(rsvinfo2, "alteaPort", 9999);
		Whitebox.setInternalState(rsvinfo2, "filePath", "./file");
		Whitebox.setInternalState(rsvinfo2, "httpMethod", "GET");

		doNothing().when(rsvinfo2).openConnection(any());
		doReturn("DummyRequest").when(rsvinfo2).createReserveInformationRequest(anyString());
		doReturn("Reserve_Information_1234567").when(rsvinfo2).getReserveInformationRequest(anyString());

		String responseMsg = rsvinfo2.getReserveInformation("123456");
		String expected = "Reserve_Information_1234567";

		assertEquals(expected, responseMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得することを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);
	}

	@Test
	public void getReserveInformation_respNot200() throws Exception {
		String method = "getReserveInformation";
		int number = 1;

		// モック戻り値の設定
		doReturn(500).when(urlConn).getResponseCode();
		doReturn("test<soapenv:Envelope>test<soapenv:Header>test</soapenv:Header><soapenv:Body>",
				"<reserveDetails><reserveInformation>Reserve_", "Information_1234567</reserveInformation>",
				"</reserveDetails></soapenv:Body></soapenv:Envelope>",
				null).when(reader).readLine();

		String requestMsg = rsvinfo.createReserveInformationRequest("123456");
		assertNotNull(requestMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaへのリクエストメッセージが作成されること";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);

		String responseMsg = rsvinfo.getReserveInformationRequest("123456");
		assertNull(responseMsg);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得できないことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);
	}

	@Test
	public void getReserveInformation_openConnection_exception() throws Exception {
		String method = "getReserveInformation";
		int number = 1;

		URL url = createTestURL(500, "");
		rsvinfo.openConnection(url);

		// モック戻り値の設定
		//doReturn(500).when(urlConn).getResponseCode();
		doReturn("test<soapenv:Envelope>test<soapenv:Header>test</soapenv:Header><soapenv:Body>",
				"<reserveDetails><reserveInformation>Reserve_", "Information_1234567</reserveInformation>",
				"</reserveDetails></soapenv:Body></soapenv:Envelope>",
				null).when(reader).readLine();

		String requestMsg = rsvinfo.createReserveInformationRequest("123456");
		assertNotNull(requestMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaへのリクエストメッセージが作成されること";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);

		String responseMsg = rsvinfo.getReserveInformationRequest("123456");
		assertNull(responseMsg);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得できないことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);
	}

	@Test
	public void getReserveInformation_closeConnection() throws Exception {
		rsvinfo.closeConnection();
	}

	@Test
	public void getReserveInformation_closeConnectionAlreadyClose() throws Exception {
		new ReserveInformation().closeConnection();
	}

	@Test
	public void getReserveInformation_conn_failException() throws Exception {
		String method = "getReserveInformation";
		int number = 1;

		// モック戻り値の設定
		doThrow(new IOException("Error occurred")).when(urlConn).getResponseCode();
		doReturn("test<soapenv:Envelope>test<soapenv:Header>test</soapenv:Header><soapenv:Body>",
				"<reserveDetails><reserveInformation>Reserve_", "Information_1234567</reserveInformation>",
				"</reserveDetails></soapenv:Body></soapenv:Envelope>",
				null).when(reader).readLine();

		String requestMsg = rsvinfo.createReserveInformationRequest("123456");
		assertNotNull(requestMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaへのリクエストメッセージが作成されること";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);

		String responseMsg = rsvinfo.getReserveInformationRequest("123456");
		assertNull(responseMsg);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得できないことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);
	}

	@Test
	public void getReserveInformation_read_failException() throws Exception {
		String method = "getReserveInformation";
		int number = 1;

		// モック戻り値の設定
		doReturn(200).when(urlConn).getResponseCode();
		doThrow(new IOException("Read error occurred")).when(reader).readLine();

		String requestMsg = rsvinfo.createReserveInformationRequest("123456");
		assertNotNull(requestMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaへのリクエストメッセージが作成されること";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);

		String responseMsg = rsvinfo.getReserveInformationRequest("123456");
		assertNull(responseMsg);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaから予約情報を取得できないことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut);
	}

	@Test
	public void extractValue_test() {
		String method = "extractValue";
		int number = 1;

		String responseMsg = "test<soapenv:Envelope>test<soapenv:Header>test</soapenv:Header><soapenv:Body><reserveDetails><reserveInformation>test_reserveInformation_123</reserveInformation></reserveDetails></soapenv:Body></soapenv:Envelope>";
		String testValue = rsvinfo.extractValue(responseMsg, ReserveInformation.TAG_SOAP_ENVELOPE);
		String expected = "test<soapenv:Header>test</soapenv:Header><soapenv:Body><reserveDetails><reserveInformation>test_reserveInformation_123</reserveInformation></reserveDetails></soapenv:Body>";
		assertEquals(expected, testValue);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", soapenv:Envelopeの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue(testValue, ReserveInformation.TAG_SOAP_BODY);
		expected = "<reserveDetails><reserveInformation>test_reserveInformation_123</reserveInformation></reserveDetails>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", soapenv:Bodyの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue(testValue, ReserveInformation.TAG_RESERVE_DETAIL);
		expected = "<reserveInformation>test_reserveInformation_123</reserveInformation>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", reserveDetailsの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue(testValue, ReserveInformation.TAG_RESERVE_INFO);
		expected = "test_reserveInformation_123";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", reserveInformationの値を取り出すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue(null, ReserveInformation.TAG_RESERVE_INFO);
		assertNull(testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", 第一引数がnullの場合、nullを返すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue("<reserveInformation>test_reserveInformation_123</reserveInformation>", null);
		expected = "<reserveInformation>test_reserveInformation_123</reserveInformation>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", 第二引数がnullの場合、第一引数を返すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);

		testValue = rsvinfo.extractValue("<reserveInformation>test_reserveInformation_123</reserveInformation>", "dummytag");
		expected = "<reserveInformation>test_reserveInformation_123</reserveInformation>";
		assertEquals(expected, testValue);
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", 第一引数の文字列の中にtagが存在しない場合、第一引数を返すことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testValue);
	}

	@Test
	public void wsSecurity_test() {
		String method = "wsSecurity";
		int number = 1;

		HashMap<String, String> testHash = rsvinfo.wsSecurity();

		assertNotNull(testHash.get("Created"));
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Createdの値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testHash.get("Created"));

		assertNotNull(testHash.get("Nonce"));
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", Nonceの値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testHash.get("Nonce"));

		assertNotNull(testHash.get("Password"));
		ut = junitTest+","+ CLASS+","+method+","+(number++)+", Passwordの値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+testHash.get("Password"));
	}


	@Test
	public void createPasswd_test() {
		String method = "createPasswd";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		long Epoch = date.getTime();

		//Created
		String created = rsvinfo.createCreated(Epoch);
		String createdHex = rsvinfo.createCreatedHex(created);
		//Nonce
		String noceHex = rsvinfo.createNonceHex(Epoch);
		String nonce = rsvinfo.createNonce(noceHex);
		//password
		String passwdSha = rsvinfo.createPasswdSha();
		String passwd = rsvinfo.createPasswd(noceHex, createdHex, passwdSha);

		String expected = "C3160D7F0030A1A71194DF29D2DBB16D38620DE0";
		// assertEquals(expected, passwd);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", NonceとCreatedとPasswordのハッシュ値をBase64エンコードした値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+passwd);
	}

	@Test
	public void createNonce_test() {
		String method = "createNonce";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		long Epoch = date.getTime();

		//ReserveInformation rsvinfo = new ReserveInformation();
		String noceHex = rsvinfo.createNonceHex(Epoch);
		String nonce = rsvinfo.createNonce(noceHex);
		String expected = "TqNLTKpSlKrr+WWbghe+jA==";
		// assertEquals(expected, nonce);
		// String ut = junitTest+","+ CLASS+","+method+","+(number++)+", NonceをBase64エンコードした値が生成されることを確認";
		// OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+nonce);
	}

	@Test
	public void createNonceHex_test() {
		String method = "createNonceHex";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		long Epoch = date.getTime();
		System.out.println("Epoch_nc: "+Epoch);

		//ReserveInformation rsvinfo = new ReserveInformation();
		String noceHex = rsvinfo.createNonceHex(Epoch);
		String expected = "4EA34B4CAA5294AAEBF9659B8217BE8C";
		// assertEquals(expected.toLowerCase(), noceHex);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", CreatedをHEX変換した値が生成されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+noceHex);
	}


	@Test
	public void createCreatedHex_test() {
		String method = "createCreatedHex";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		long Epoch = date.getTime();

		//ReserveInformation rsvinfo = new ReserveInformation();
		String created = rsvinfo.createCreated(Epoch);
		String createdHex = rsvinfo.createCreatedHex(created);
		String expected = "323032302d30332d31365430383a31383a31312e3032395a";
		// assertEquals(expected, createdHex);
		// String ut = junitTest+","+ CLASS+","+method+","+(number++)+", CreatedをHEX変換した値が生成されることを確認";
		// OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+createdHex);
	}

	@Test
	public void createCreated_test() {
		String method = "createCreated";
		int number = 1;

		String dateStr = "2020-03-16T08:18:11.029Z";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date date=null;
		try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		long Epoch = date.getTime();
		System.out.println("Epoch_cr: "+Epoch);

		//ReserveInformation rsvinfo = new ReserveInformation();
		String created = rsvinfo.createCreated(Epoch);
		String expected = dateStr;
		// assertEquals(expected, created);
		// String ut = junitTest+","+ CLASS+","+method+","+(number++)+", 時刻情報からCreatedが生成されることを確認";
		// OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+created);
	}


	@Test
	public void createPasswdSha_test() {
		String method = "createPasswdSha";
		int number = 1;

		//ReserveInformation rsvinfo = new ReserveInformation();
		String passSha = rsvinfo.createPasswdSha();
		String expected = "4243f3ff732f14a562aca4cb6d837cc05726055d";
		// assertEquals(expected, passSha);
		// String ut = junitTest+","+ CLASS+","+method+","+(number++)+", AlteaのパスワードからSHA-1のメッセージダイジェストが生成されることを確認";
		// OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+passSha);
	}


	@Test
	public void createReserveInformationRequest_test() {
		String method = "createReserveInformationRequest";
		int number = 1;

		Random random = new Random();
		int randomValue = random.nextInt(1000000);

		String reserveNum = String.format("%06d", randomValue);
		System.out.println("reserveNum: "+reserveNum);

		//ReserveInformation rsvinfo = new ReserveInformation();
		String requestMsg = rsvinfo.createReserveInformationRequest(reserveNum);

		assertNotNull(requestMsg);
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", 予約情報取得要求を作成することを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +",requestMsg:"+requestMsg);

	}

	@Test
	public void getReserveInformationRequest_NG_test() {
		String method = "getReserveInformationRequest";
		int number = 2;

		Random random = new Random();
		int randomValue = random.nextInt(1000000);

		String reserveNum = String.format("%06d", randomValue);
		System.out.println("reserveNum: "+reserveNum);

		ReserveInformation rsvinfo = new ReserveInformation();
		// SOAPMessage requestMsg = rsvinfo.createReserveInformationRequest(reserveNum);

		String responseMsg = rsvinfo.getReserveInformationRequest("aaaaa,bbbb,cccc");

		//Deencapsulation.setField(rsvinfo, "ALTEA_URL", "http://xxxxx/xxxxx");

		StringWriter writer = new StringWriter();
		WriterAppender appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);
		//aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
		try {
			String logString = writer.toString();
			// assertNull(responseMsg);
			// assertTrue(logString.contains("Altea IO ERROR."));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}
		//aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
		String ut = junitTest+","+ CLASS+","+method+","+(number++)+", Alteaとの接続失敗時、予約情報を取得できないことを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+responseMsg);

	}

	public void renameLogFile() {
		Calendar cl = Calendar.getInstance();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		System.out.println(sdf.format(cl.getTime()));

		try {
			Path srcPath = Paths.get(LogFileName);
			Path trgPath = Paths.get(LogFileName+"_"+sdf.format(cl.getTime()));

			Files.move(srcPath, trgPath);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			//e.printStackTrace();
		}
	}
}