package jp.co.ana.cas.proto.util;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import org.apache.log4j.LogManager;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.WriterAppender;
import org.junit.jupiter.api.Test;

public class OutputLogTest{
	public static final String LogFileName = "Junit.log";
	public static final String junitTest = "[JunitTest]";
 	public static final String  CLASS = "OutputLog";

	@Test
	public void outputLogMessage_test() {
		String method = "outputLogMessage";
		int number = 1;

//		renameLogFile();

        Calendar cl = Calendar.getInstance();

        //SimpleDateFormatクラスでフォーマットパターンを設定する
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

        Random random = new Random();
        String randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());

        StringWriter writer = new StringWriter();
		WriterAppender appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);
		OutputLog.outputLogMessage(OutputLog.DEBUG, "dummy");
		String lastLine = null;

        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", DEBUGレベルでログが出力されることを確認";

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());
        System.out.println("randomValue: " + randomValue);

        writer = new StringWriter();
		appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);
		String logString = null;

		try {
			OutputLog.outputLogMessage(OutputLog.INFO, randomValue);
			OutputLog.outputLogMessage(OutputLog.DEBUG, randomValue);
			logString = writer.toString();
			assertTrue(logString.contains(randomValue));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}

        ut = junitTest+","+ CLASS+","+method+","+(number++)+", INFOレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.INFO, ut +","+logString);
        System.out.println(logString);

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());

        writer = new StringWriter();
		appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);

		try {
			OutputLog.outputLogMessage(OutputLog.WARN, randomValue);
			logString = writer.toString();
			assertTrue(logString.contains(randomValue));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}

        ut = junitTest+","+ CLASS+","+method+","+(number++)+", WARNレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.WARN, ut +","+logString);
        System.out.println(logString);

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());

        writer = new StringWriter();
		appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);

		try {
			OutputLog.outputLogMessage(OutputLog.ERROR, randomValue);
			logString = writer.toString();
			assertTrue(logString.contains(randomValue));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}

        ut = junitTest+","+ CLASS+","+method+","+(number++)+", ERRORレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.ERROR, ut +","+logString);
        System.out.println(logString);

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());
        System.out.println("randomValue: " + randomValue);

        writer = new StringWriter();
		appender = new WriterAppender(new PatternLayout("%p, %m%n"), writer);
		LogManager.getRootLogger().addAppender(appender);
		LogManager.getRootLogger().setAdditivity(false);

		try {
			OutputLog.outputLogMessage(OutputLog.FATAL, randomValue);
			logString = writer.toString();
			assertTrue(logString.contains(randomValue));
		} finally {
			LogManager.getRootLogger().removeAppender(appender);
			LogManager.getRootLogger().setAdditivity(true);
		}

        ut = junitTest+","+ CLASS+","+method+","+(number++)+", FATALレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.FATAL, ut +","+logString);
        System.out.println(logString);
    }

	public void renameLogFile() {
		Calendar cl = Calendar.getInstance();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        System.out.println(sdf.format(cl.getTime()));

        Path srcPath = Paths.get(LogFileName);
        Path trgPath = Paths.get(LogFileName+"_"+sdf.format(cl.getTime()));
        try {
			Files.move(srcPath, trgPath);
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}
}
