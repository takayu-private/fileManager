package jp.co.ana.cas.proto.util;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;

import util.OutputLog;

public class OutputLogTest{
	public static final String LogFileName = "Junit.log";
	public static final String junitTest = "[JunitTest]";
 	public static final String  CLASS = "OutputLog";
 	
//	@Test
	public void outputLogMessage_test() {
		String method = "outputLogMessage";
		int number = 1;

        Calendar cl = Calendar.getInstance();

        //SimpleDateFormatクラスでフォーマットパターンを設定する
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
//        System.out.println(sdf.format(cl.getTime()));

        Random random = new Random();
        String randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());
        System.out.println("randomValue: " + randomValue);
		OutputLog.outputLogMessage(OutputLog.DEBUG, randomValue);
        String lastLine = getLog("DEBUG");
        assertTrue(lastLine.indexOf(randomValue) > -1);
        String ut = junitTest+","+ CLASS+","+method+","+(number++)+", DEBUGレベルでログが出力されることを確認";
		OutputLog.outputLogMessage(OutputLog.DEBUG, ut +","+lastLine);
        System.out.println(lastLine);

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());
        System.out.println("randomValue: " + randomValue);
        OutputLog.outputLogMessage(OutputLog.INFO, randomValue);
        lastLine = getLog("INFO");
        assertTrue(lastLine.indexOf(randomValue) > -1);
        ut = junitTest+","+ CLASS+","+method+","+(number++)+", INFOレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.INFO, ut +","+lastLine);
        System.out.println(lastLine);

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());
        System.out.println("randomValue: " + randomValue);
        OutputLog.outputLogMessage(OutputLog.WARN, randomValue);
        lastLine = getLog("WARN");
        assertTrue(lastLine.indexOf(randomValue) > -1);
        ut = junitTest+","+ CLASS+","+method+","+(number++)+", WARNレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.WARN, ut +","+lastLine);
        System.out.println(lastLine);

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());
        System.out.println("randomValue: " + randomValue);
         OutputLog.outputLogMessage(OutputLog.ERROR, randomValue);
        lastLine = getLog("ERROR");
        assertTrue(lastLine.indexOf(randomValue) > -1);
        ut = junitTest+","+ CLASS+","+method+","+(number++)+", ERRORレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.ERROR, ut +","+lastLine);
        System.out.println(lastLine);

        cl = Calendar.getInstance();
        random = new Random();
        randomValue = String.valueOf(random.nextInt(1000000000));
        randomValue += "-" + sdf.format(cl.getTime());
        System.out.println("randomValue: " + randomValue);
        OutputLog.outputLogMessage(OutputLog.FATAL, randomValue);
        lastLine = getLog("FATAL");
        assertTrue(lastLine.indexOf(randomValue) > -1);
        ut = junitTest+","+ CLASS+","+method+","+(number++)+", FATALレベルでログが出力されることを確認";
        OutputLog.outputLogMessage(OutputLog.FATAL, ut +","+lastLine);
        System.out.println(lastLine);
    }


	public void renameLogFile() {
		Calendar cl = Calendar.getInstance();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        System.out.println(sdf.format(cl.getTime()));

        Path srcPath = Paths.get(LogFileName);
        Path trgPath = Paths.get(LogFileName+"_"+sdf.format(cl.getTime()));
        try {
			Files.move(srcPath, trgPath);
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

	public String getLog(String msg) {

        List<String> lines = new ArrayList<String>();
        try {
        	Path path = Paths.get(LogFileName);
            lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(int counter = lines.size()-1;  counter >= 0; --counter ) {
        	if(lines.get(counter).indexOf(msg)!= -1) {
        		return lines.get(counter);
        	}
        }
        return "";
	}

	public String getLog(int num) {

        List<String> lines = new ArrayList<String>();
        try {
        	Path path = Paths.get(LogFileName);
            lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines.get(lines.size()-num);
	}

	public String getFinalLog() {

        List<String> lines = new ArrayList<String>();
        try {
        	Path path = Paths.get(LogFileName);
            lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines.get(lines.size()-1);
	}

}
