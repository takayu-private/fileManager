package jp.co.ana.cas.proto.util;

import com.fasterxml.jackson.databind.util.ISO8601DateFormat;
import com.fasterxml.jackson.databind.util.ISO8601Utils;
import com.fasterxml.jackson.databind.util.StdDateFormat;

import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Date;


public class RFC3339DateFormat extends StdDateFormat {
	
	private static final long serialVersionUID = 1L;
	
	private static final String ISO8601_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	
	// Same as ISO8601DateFormat but serializing milliseconds.
	@Override
	public StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition) {
		String value = new SimpleDateFormat(ISO8601_DATE_FORMAT).format(date);
		toAppendTo.append(value);
		return toAppendTo;
	}
}