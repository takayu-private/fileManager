package jp.co.ana.cas.proto.util;


import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;

public class GijiSvf {
    public static final String CRLF = "\r\n";

	public static void main(String[] args) throws Exception {
        System.out.println("start >>>");

        ServerSocket server = null;
        Socket socket = null;
        InputStream in = null;
        BufferedWriter bw = null;
        try {
        server = new ServerSocket(8082);
        }
        catch(Exception ex){
        	System.out.println("Error. ex="+ex);
        	return;
        }

        while(true) {
        try {
            socket = server.accept();
            System.out.println("[SVF] クライアントから要求受信!!");
            in = socket.getInputStream();
            bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            String filePath = "/home/ec2-user/nec-work/pdf/";
            String originalFileName = "prototype_test.pdf";
            byte[] input_file = Files.readAllBytes(Paths.get(filePath+originalFileName));
            byte[] encodedBytes = Base64.getEncoder().encode(input_file);
//            String encodedString =  new String(encodedBytes);
            bw.write("HTTP/1.1 200 OK" + CRLF);
            bw.write("Content-Type: application/pdf" + CRLF);
            bw.write(CRLF);
            String encodedString = "QxL1Jvb3QgMSAwIFIvSW5mbyAxNCAwIFIvSURbPDUxNEUwQjhBQUI3NjdCNDQ5OUQzNEUwODJFOEMzNERCPjw1MTRFMEI4QUFCNzY3QjQ0OTlEMzRFMDgyRThDMzREQj5dIC9QcmV2IDM3NDUzL1hSZWZTdG0gMzcxMjM+Pg0Kc3RhcnR4cmVmDQozODQzMA0KJSVFT0Y=";
            bw.write(encodedString);
            bw.flush();
            
            try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
            HttpRequest request = new HttpRequest(in);
            System.out.println("[SVF] Header: "+request.getHeaderText());
            System.out.println("[SVF] Body: "+request.getBodyText());
        }
        catch(Exception ex){
        	System.out.println("Error. ex="+ex);
            in.close();
            bw.close();
            socket.close();
            server.close();
        	return;
        }
        in.close();
        bw.close();
        socket.close();

        System.out.println("[SVF] クライアントへの応答完了!!");
        }
    }
}