package util;


import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class GijiAltea {
    public static final String CRLF = "\r\n";

	public static void main(String[] args) throws Exception {
        System.out.println("start >>>");

        ServerSocket server = null;
        Socket socket = null;
        InputStream in = null;
        BufferedWriter bw = null;
        try {
        server = new ServerSocket(8081);
        }
        catch(Exception ex){
        	System.out.println("Error. ex="+ex);
        	return;
        }

        while(true) {
        try {
            socket = server.accept();
            System.out.println("クライアントから要求受信!!");
            in = socket.getInputStream();
            bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

//			StringBuilder sb = new StringBuilder();
//			String body;
			// レスポンスのHTTP body取得

//			sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
////			sb.append(CRLF);
//			sb.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:awsse=\"http://xml.amadeus.com/2010/06/Session_v3\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">");
////			sb.append(CRLF);
//			sb.append("<soapenv:Header>");
////			sb.append(CRLF);
//			sb.append("<wsa:To>http://www.w3.org/2005/08/addressing/anonymous</wsa:To>");
////			sb.append(CRLF);
//			sb.append("<wsa:From>");
////			sb.append(CRLF);
//			sb.append("<wsa:Address>https://nodeA1.test.webservices.amadeus.com/1ASIWGENNH</wsa:Address>");
////			sb.append(CRLF);
//			sb.append("</wsa:From>");
////			sb.append(CRLF);
//			sb.append("<wsa:Action>http://webservices.amadeus.com/FLIREQ_97_3_1A</wsa:Action>");
////			sb.append(CRLF);
//			sb.append("<wsa:MessageID>urn:uuid:6299d20d-0a70-4134-1956-e20a49c7ebfa</wsa:MessageID>");
////			sb.append(CRLF);
//			sb.append("<wsa:RelatesTo RelationshipType=\"http://www.w3.org/2005/08/addressing/reply\">uuid:8f24c8a3-5d2b-4ccb-9911-e93971e527a6</wsa:RelatesTo>");
////			sb.append(CRLF);
//			sb.append("<awsse:Session TransactionStatusCode=\"End\">");
////			sb.append(CRLF);
//			sb.append("<awsse:SessionId>00JC1C805I</awsse:SessionId>");
////			sb.append(CRLF);
//			sb.append("<awsse:SequenceNumber>1</awsse:SequenceNumber>");
////			sb.append(CRLF);
//			sb.append("<awsse:SecurityToken>2J2MBBX7ATIJ03R7OBAZ8ZOHUI</awsse:SecurityToken>");
////			sb.append(CRLF);
//			sb.append("</awsse:Session>");
////			sb.append(CRLF);
//			sb.append("</soapenv:Header>");
////			sb.append(CRLF);
//			sb.append("<soapenv:Body>");
////			sb.append(CRLF);
//			sb.append("<reserveDetails>");
////			sb.append(CRLF);
//			sb.append("<reserveInformation>Reserve_Information_1234567</reserveInformation>");
////			sb.append(CRLF);
//			sb.append("</reserveDetails>");
////			sb.append(CRLF);
//			sb.append("</soapenv:Body>");
////			sb.append(CRLF);
//			sb.append("</soapenv:Envelope>");
////			sb.append(CRLF);
//			body = sb.toString();
//			System.out.println("body: " + body);
//			MessageFactory msgFactory = null;
//			SOAPMessage responseMsg = null;
//
//				InputStream soapByte = new ByteArrayInputStream(body.getBytes());
//				msgFactory = MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
//				responseMsg = msgFactory.createMessage(null, soapByte);



            bw.write("HTTP/1.1 200 OK" + CRLF);
            bw.write("Content-Encoding: gzip" + CRLF);
            bw.write("Content-Type: text/xml" + CRLF);
            bw.write("Content-Length: 256" + CRLF);
            bw.write(CRLF);
            bw.flush();
			bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			bw.flush();
//			bw.write(CRLF);
			bw.write("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" ");
			bw.write(" xmlns:awsse=\"http://xml.amadeus.com/2010/06/Session_v3\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">");

			//			bw.write(CRLF);
			bw.flush();
			bw.write("<soapenv:Header>");
//			bw.write(CRLF);
			bw.write("<wsa:To>http://www.w3.org/2005/08/addressing/anonymous</wsa:To>");
//			bw.write(CRLF);
			bw.write("<wsa:From>");
//			bw.write(CRLF);
			bw.write("<wsa:Address>https://nodeA1.test.webservices.amadeus.com/1ASIWGENNH</wsa:Address>");
//			bw.write(CRLF);
			bw.write("</wsa:From>");
//			bw.write(CRLF);
			bw.write("<wsa:Action>http://webservices.amadeus.com/FLIREQ_97_3_1A</wsa:Action>");
//			bw.write(CRLF);
			bw.write("<wsa:MessageID>urn:uuid:6299d20d-0a70-4134-1956-e20a49c7ebfa</wsa:MessageID>");
//			bw.write(CRLF);
			bw.write("<wsa:RelatesTo RelationshipType=\"http://www.w3.org/2005/08/addressing/reply\">uuid:8f24c8a3-5d2b-4ccb-9911-e93971e527a6</wsa:RelatesTo>");
//			bw.write(CRLF);
			bw.write("<awsse:Session TransactionStatusCode=\"End\">");
//			bw.write(CRLF);
			bw.write("<awsse:SessionId>00JC1C805I</awsse:SessionId>");
//			bw.write(CRLF);
			bw.write("<awsse:SequenceNumber>1</awsse:SequenceNumber>");
//			bw.write(CRLF);
			bw.write("<awsse:SecurityToken>2J2MBBX7ATIJ03R7OBAZ8ZOHUI</awsse:SecurityToken>");
//			bw.write(CRLF);
			bw.write("</awsse:Session>");
//			bw.write(CRLF);
			bw.write("</soapenv:Header>");
//			bw.write(CRLF);
			bw.write("<soapenv:Body>");
//			bw.write(CRLF);
			bw.write("<reserveDetails>");
//			bw.write(CRLF);
			bw.write("<reserveInformation>Reserve_Information_1234567</reserveInformation>");
//			bw.write(CRLF);
			bw.write("</reserveDetails>");
//			bw.write(CRLF);
			bw.write("</soapenv:Body>");
//			bw.write(CRLF);
			bw.write("</soapenv:Envelope>");
            bw.flush();
            HttpRequest request = new HttpRequest(in);
            System.out.println("getHeaderText(): "+request.getHeaderText());
            System.out.println("getBodyText(): "+request.getBodyText());
        }
        catch(Exception ex){
        	System.out.println("Error. ex="+ex);
            in.close();
            bw.close();
            socket.close();
            server.close();
        	return;
        }
        in.close();
        bw.close();
        socket.close();

        System.out.println("クライアントへの応答完了!!");
        }
    }
}