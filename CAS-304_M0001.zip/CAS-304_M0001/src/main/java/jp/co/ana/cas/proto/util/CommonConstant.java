package jp.co.ana.cas.proto.util;


public class CommonConstant {


	//proxy情報
	public static final String PROXY_ADDRESS = "proxygate2.nic.nec.co.jp";
	public static final int PROXY_PORT = 8080;

	//Altea情報
	//public static final String ALTEA_URL = "https://nodeA1.test.webservices.amadeus.com/1ASIWGENNH";
	public static final String ALTEA_URL = "http://cas-proto-altea:8081";
	public static final String ALTEA_USER = "DMSPSS";
	public static final String ALTEA_PASSWD = "2JSb0jXN";

	//DB情報
	public static final String DRIVER_URL = "jdbc:postgresql://cas.cluster-cicfzk0y5s0q.ap-northeast-1.rds.amazonaws.com:5432/anaorg";;

	public static final String DB_USER = "postgres";
	public static final String DB_PASSWD = "postgres";
	public static final String INSERT_SQL = "INSERT INTO report_list (file_name,file_data) values(?,?);";
}
