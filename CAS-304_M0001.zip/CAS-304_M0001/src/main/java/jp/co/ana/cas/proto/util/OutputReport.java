package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * 帳票出力クラス.
 * @author 113105A00ACF0
 *
 */
public class OutputReport {
	//DB情報
	public final String DRIVER_URL = "jdbc:postgresql://13.231.66.58:5432/postgres";

	//SVF情報
	// ホストを示すドメイン名。
	public final String SVF_HOST = "localhost";
	// プロトコル。
	public static final String PROTOCOL = "http";
	// ポート番号。
	public static final int SVF_PORT = 8080;
	// ファイルパス。
	public static final String FILE_PATH = "";
	// HTTPメソッド
	public static final String HTTP_METHOD = "POST";
	//Insert文
	//String insertSql = CommonConstant.INSERT_SQL;

	// 予約情報
	private String csvReserveInfo;

	// 帳票ファイル情報
	private String reportFile;

	/**
	 * 帳票出力メイン処理.
	 * @param reserveNum
	 */
	public void outputReportMain(String reserveNum) {
		//予約情報取得
		ReserveInformation reserveInfo = new ReserveInformation();
		csvReserveInfo = reserveInfo.getReserveInformation(reserveNum);
		OutputLog.outputLogMessage(OutputLog.DEBUG, "csvReserveInfo: " + csvReserveInfo);

		//帳票作成
		reportFile = outputReportRequest(csvReserveInfo);
		OutputLog.outputLogMessage(OutputLog.DEBUG, "reportFile: " + reportFile);
		//帳票格納
		insertReport(reserveNum, reportFile);

		//ログ出力
		OutputLog.outputLogMessage(OutputLog.INFO, "帳票出力が完了しました。");
	}

	public String outputReportRequest(String csvReserveInfo) {
		HttpURLConnection  urlConn = null;
		InputStream in = null;
		BufferedReader reader = null;
		String report = null;

		try {
			System.out.println("HttpConnect START!!");
			//接続するURLを指定する
			URL url = new URL( PROTOCOL, SVF_HOST, SVF_PORT, FILE_PATH );
			//コネクションを取得する
			urlConn = (HttpURLConnection) url.openConnection();
			// HTTPメソッドを設定する
			//    urlConn.setRequestMethod("GET");
			urlConn.setRequestMethod(HTTP_METHOD);
			// リスエストとボディ送信を許可する
			urlConn.setDoOutput(true);
			// レスポンスのボディ受信を許可する
			urlConn.setDoInput(true);
			// コネクション接続
			urlConn.connect();
			PrintStream ps = new PrintStream(urlConn.getOutputStream());
			//
			ps.print(csvReserveInfo);
			//System.out.println("connect OK!!");
			int status = urlConn.getResponseCode();
			System.out.println("HTTP status code:" + status);
			OutputLog.outputLogMessage(OutputLog.DEBUG, "SVF HTTP status code:" + status);
//			String headerKey = null;
//			int counter = 0;
			// レスポンスのHTTP header取得
//			while ((headerKey = urlConn.getHeaderFieldKey(++counter)) != null) {
//				System.out.println(headerKey + ": "+ urlConn.getHeaderField(counter));
//			}

			if(status == HttpURLConnection.HTTP_OK) {

				in = urlConn.getInputStream();
				reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder sb = new StringBuilder();
				String line;
				// レスポンスのHTTP body取得
				while ((line = reader.readLine()) != null) {
					sb.append(line);
				}
				report = sb.toString();
				System.out.println("body部: "+report);
				OutputLog.outputLogMessage(OutputLog.DEBUG, "SVF HTTP body:" + report);
			}
		} catch (Exception e) {
			e.printStackTrace();
			OutputLog.outputLogMessage(OutputLog.ERROR, "SVF IO ERROR. " + e);
		} finally {
			try {
				if(reader != null) {
					reader.close();					
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			urlConn.disconnect();
		}
		return report;
	}

	public void insertReport(String reserveNum, String reportFile) {
		//帳票のファイル名
		String repFileName = "report_" + reserveNum + ".pdf";

		try{

			//PostgreSQLへ接続
			Connection conn = DriverManager.getConnection(DRIVER_URL, CommonConstant.DB_USER, CommonConstant.DB_PASSWD);

			//自動コミットOFF
			conn.setAutoCommit(false);

			//Insert文編集
			PreparedStatement ps = conn.prepareStatement(CommonConstant.INSERT_SQL);
			ps.setString(1, repFileName);
			ps.setString(2, reportFile);
			//Insert実行
			ps.executeUpdate();
			conn.commit();

		} catch (Exception e) {
			e.printStackTrace();
			OutputLog.outputLogMessage(OutputLog.ERROR, "ORG DB ERROR. " + e);
		}
	}


}