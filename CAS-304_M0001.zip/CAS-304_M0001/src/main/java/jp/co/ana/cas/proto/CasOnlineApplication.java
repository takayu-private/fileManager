package jp.co.ana.cas.proto;

import org.openapitools.jackson.nullable.JsonNullableModule;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;

import com.fasterxml.jackson.databind.Module;

import jp.co.ana.cas.proto.util.OutputLog;
import jp.co.ana.cas.proto.util.ReceiveReportRequest;

@SpringBootApplication
public class CasOnlineApplication implements CommandLineRunner {

	@Override
	public void run(String... arg0) throws Exception {
		if (arg0.length > 0 && arg0[0].equals("exitcode")) {
				throw new ExitException();
		}
		
		//帳票作成要求受信
		while(true) {
			ReceiveReportRequest recRepRequest = new ReceiveReportRequest();
			recRepRequest.reportCreateMain();
//			Calendar cl = Calendar.getInstance();
//	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SSS");
//	        System.out.println(sdf.format(cl.getTime())+ " queue checked!!");
	        OutputLog.outputLogMessage(OutputLog.DEBUG, "queue checked!!");
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(CasOnlineApplication.class, args);
	}
	
	static class ExitException extends RuntimeException implements ExitCodeGenerator {
		private static final long serialVersionUID = 1L;

		@Override
		public int getExitCode() {
				return 10;
		}
	}

	@Bean
	public WebMvcConfigurer webConfigurer() {
		return new WebMvcConfigurer() {
				/*@Override
				public void addCorsMappings(CorsRegistry registry) {
						registry.addMapping("/**")
										.allowedOrigins("*")
										.allowedMethods("*")
										.allowedHeaders("Content-Type");
				}*/
		};
	}

	@Bean
	public Module jsonNullableModule() {
		return new JsonNullableModule();
	}
}
