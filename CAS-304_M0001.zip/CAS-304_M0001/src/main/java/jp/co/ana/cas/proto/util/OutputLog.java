package jp.co.ana.cas.proto.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class OutputLog {
	private static Logger log = Logger.getLogger(OutputLog.class);

	public static final int DEBUG = 1;
	public static final int INFO = 2;
	public static final int WARN = 3;
	public static final int ERROR = 4;
	public static final int FATAL = 5;


	static {
		// 設定ファイルを読み込む
		DOMConfigurator.configure("/opt/cas/lib/log4j.xml");
//	    String path = new File(".").getAbsoluteFile().getParent();
//        System.out.println("currentDirectory="+path);

	}


	public static void outputLogMessage(int level, String message){
		Calendar cl = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SSS");
        System.out.println(sdf.format(cl.getTime())+ " " + message);
		switch(level) {
		case DEBUG:
			log.debug(message);
			break;
		case INFO:
			log.info(message);
			break;
		case WARN:
			log.warn(message);
			break;
		case ERROR:
			log.error(message);
			break;
		case FATAL:
			log.fatal(message);
			break;
		default:
			// 何もしない (そもそも、ここに到達しない)
		}
	}
}