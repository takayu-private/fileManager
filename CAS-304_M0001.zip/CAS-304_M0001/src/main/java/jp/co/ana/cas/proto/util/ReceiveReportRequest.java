package jp.co.ana.cas.proto.util;

import java.io.StringReader;
import java.util.Objects;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


/**
 * 帳票作成要求取得クラス.
 * @author 113105A00ACF0
 *
 */
public class ReceiveReportRequest {

	//ANA予約番号桁数
	public static final int RESERVE_NUM_LENGTH = 6;
	//Amazon MQ情報
	private final String mqEndpoint;
	private final String mqUser;
	private final String mqPasswd;
	private final String mqQueName;

	private Connection consumerConnection = null;
	private Session consumerSession = null;
	private Destination consumerDestination = null; 
	private MessageConsumer consumer = null;

	/**
	 * コンストラクタ.
	 */
	public ReceiveReportRequest() {
		mqEndpoint = System.getenv("MQ_ENDPOINT");
		mqUser = System.getenv("MQ_USER");
		mqPasswd = System.getenv("MQ_PASSWD");
		mqQueName = System.getenv("MQ_QUE_NAME");
	}

	@Override
	protected void finalize() throws Throwable {
		// クローズ忘れたまま、クラスを解放してしまわないように対策しておく
		closeConnection();
		super.finalize();
	}

	public static void main(String[] args) {
		//帳票作成要求受信
		while(true) {
			ReceiveReportRequest recRepRequest = new ReceiveReportRequest();
			recRepRequest.reportCreateMain();
			System.out.println("queue checked(2)!!");
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 帳票作成メイン処理.
	 */
	public void reportCreateMain() {
		// JMS接続用のオブジェクト作成
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(mqEndpoint);
		openConnection(connectionFactory);
		//帳票作成要求取得
		String requestMsg = getReportRequest();
		//Amazon MQへ接続を閉じる
		closeConnection();
		//ANA予約番号取り出し
		String reserveNum = extractReserveNum(requestMsg);
		//ANA予約番号取り出し結果がNull以外の場合処理続行
		if(reserveNum != null) {
			OutputReport outputReport = new OutputReport();
			outputReport.outputReportMain(reserveNum);
			OutputLog.outputLogMessage(OutputLog.DEBUG, "帳票作成処理完了");
		}
	}

	/**
	 * 帳票作成要求取得処理.
	 * @param None
	 * @return textMsg
	 */
	public String getReportRequest() {
		String requestMsg = null;

		try {
			// メッセージ待ち受け開始
			Message consumerMessage =consumer.receive(1000);
			// メール到着時に受信
			TextMessage textMsg = (TextMessage) consumerMessage;

			if(consumerMessage != null) {
				requestMsg = textMsg.getText();
				OutputLog.outputLogMessage(OutputLog.INFO, "帳票作成要求あり。 message: " + textMsg);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return requestMsg;
	}

	public void openConnection(ActiveMQConnectionFactory connectionFactory) {
		OutputLog.outputLogMessage(OutputLog.INFO, "MQ Connect START.");

		// ユーザ名とパスワードを渡す
		connectionFactory.setUserName(mqUser);
		connectionFactory.setPassword(mqPasswd);
		//コンシューマーの接続を確立
		try {
			consumerConnection = connectionFactory.createConnection();
			consumerConnection.start();
			// セッション作成
			consumerSession = consumerConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			// "MyQueue"キューを作成
			consumerDestination = consumerSession.createQueue(mqQueName);
			// セッションからキューへのコンシューマーを作成
			consumer = consumerSession.createConsumer(consumerDestination);
		} catch (JMSException e) {
			e.printStackTrace();
			OutputLog.outputLogMessage(OutputLog.ERROR, "MQ Connect ERROR. ");
		}
	}

	public void closeConnection() {
		//コンシューマーの接続を閉じる
		try {
			if(consumer != null) {
				consumer.close();
			}
		} catch (JMSException e) {
			e.printStackTrace();
		}
		//セッションの接続を閉じる
		try {
			if(consumerSession != null) {
				consumerSession.close();
			}
		} catch (JMSException e) {
			e.printStackTrace();
		}
		//キューの接続を閉じる
		try {
			if(consumerConnection != null) {
				consumerConnection.close();
			}
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 帳票作成要求からANA予約番号取り出し処理.
	 * @param requestMsg 帳票作成要求
	 * @return reserveNum ANA予約番号
	 */
	public String extractReserveNum(String requestMsg) {
		//ANA予約番号
		String reserveNum = null;

		if (Objects.equals(requestMsg,null)) {
			return reserveNum;
		}

		try {
			//帳票作成要求メッセージからANA予約番号取り出し
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document receivedDoc = documentBuilder.parse(new InputSource(new StringReader(requestMsg)));
			NodeList recievNode = receivedDoc.getElementsByTagName("pnrRecordLocator");
			reserveNum = recievNode.item(0).getTextContent();

			//ANA予約番号がNull以外または6文字か確認
			if (reserveNum == null || reserveNum.length() != RESERVE_NUM_LENGTH) {
				reserveNum = null;
			}
			OutputLog.outputLogMessage(OutputLog.INFO, "ANA予約番号: " + reserveNum);

		} catch (Exception e) {
			OutputLog.outputLogMessage(OutputLog.ERROR, "帳票作成要求不正. " + e);
			e.printStackTrace();
		}
		return reserveNum;
	}
}