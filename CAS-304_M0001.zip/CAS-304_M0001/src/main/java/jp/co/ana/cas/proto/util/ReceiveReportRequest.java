package util;

import java.io.IOException;
import java.io.StringReader;
import java.util.Objects;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


/**
 * 帳票作成要求取得クラス.
 * @author 113105A00ACF0
 *
 */
public class ReceiveReportRequest {
	//Amazon MQ情報
	//Amazon MQのブローカーのエンドポイント
	public static final String MQ_ENDPOINT = "ssl://b-b09d16cd-21f5-440e-bfc3-96decadfa911-1.mq.ap-northeast-1.amazonaws.com:61617";
	//Amazon MQのユーザ名
	public static final String MQ_USER = "CAS_Prototype";
	//Amazon MQのパスワード
	public static final String MQ_PASSWD = "CAS_Prototype";
	//キュー名
	public static final String MQ_QUE_NAME = "MyQueue";
	//ANA予約番号桁数
	public static final int RESERVE_NUM_LENGTH = 6;

	public static void main(String[] args) {
//		SpringApplication.run(ReceiveReportRequest.class, args);

		//帳票作成要求受信
		ReceiveReportRequest recRepRequest = new ReceiveReportRequest();
		recRepRequest.reportCreateMain();
	}

	/**
	 * 帳票作成メイン処理.
	 */
	public void reportCreateMain() {
		//帳票作成要求取得
		String requestMsg = getReportRequest();
		//ANA予約番号取り出し
		String reserveNum = extractReserveNum(requestMsg);

		//ANA予約番号取り出し結果がNull以外の場合処理続行
		if(reserveNum != null) {
			OutputReport outputReport = new OutputReport();
			outputReport.outputReportMain(reserveNum);
			OutputLog.outputLogMessage(OutputLog.DEBUG, "帳票作成処理完了");
		}
	}

	/**
	 * 帳票作成要求取得処理.
	 * @param None
	 * @return textMsg
	 */
	public String getReportRequest() {
		ActiveMQConnectionFactory connectionFactory = null;
		Connection consumerConnection = null;
		Session consumerSession = null;
		MessageConsumer consumer = null;
		String requestMsg = null;

		try {
			// JMS接続用のオブジェクト作成
			connectionFactory = new ActiveMQConnectionFactory(MQ_ENDPOINT);
			// ユーザ名とパスワードを渡す
			connectionFactory.setUserName(MQ_USER);
			connectionFactory.setPassword(MQ_PASSWD);
			//コンシューマーの接続を確立
			consumerConnection = connectionFactory.createConnection();
			consumerConnection.start();
			// セッション作成
			consumerSession = consumerConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			// "MyQueue"キューを作成
			Destination consumerDestination = consumerSession.createQueue(MQ_QUE_NAME);
			// セッションからキューへのコンシューマーを作成
			consumer = consumerSession.createConsumer(consumerDestination);
			// メッセージ待ち受け開始
			Message consumerMessage = consumer.receive(1000);
			// メール到着時に受信
			TextMessage textMsg = (TextMessage) consumerMessage;

			if(textMsg != null) {
				requestMsg = textMsg.getText();
			}
		} catch (Exception e) {
			e.printStackTrace();
			OutputLog.outputLogMessage(OutputLog.ERROR, "MQ Connect ERROR. " + e);
		} finally {
			//コンシューマーの接続を閉じる
			try {
				if(consumer != null) {
					consumer.close();					
				}
			} catch (JMSException e) {
				e.printStackTrace();
			}
			//セッションの接続を閉じる
			try {
				if(consumerSession != null) {
					consumerSession.close();
				}
			} catch (JMSException e) {
				e.printStackTrace();
			}
			//キューの接続を閉じる
			try {
				if(consumerConnection != null) {
					consumerConnection.close();
				}
			} catch (JMSException e) {
				e.printStackTrace();
			}
		}
		return requestMsg;
	}

	/**
	 * 帳票作成要求からANA予約番号取り出し処理.
	 * @param requestMsg 帳票作成要求
	 * @return reserveNum ANA予約番号
	 */
	public String extractReserveNum(String requestMsg) {
		//ANA予約番号
		String reserveNum = null;

		if (Objects.equals(requestMsg,null)) {
			return reserveNum;
		}

		try {
			//帳票作成要求メッセージからANA予約番号取り出し
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document receivedDoc = documentBuilder.parse(new InputSource(new StringReader(requestMsg)));
			NodeList recievNode = receivedDoc.getElementsByTagName("pnrRecordLocator");
			reserveNum = recievNode.item(0).getTextContent();

			//ANA予約番号がNull以外または6文字か確認
			if (reserveNum == null || reserveNum.length() != RESERVE_NUM_LENGTH) {
				reserveNum = null;
			}

		} catch (Exception e) {
			OutputLog.outputLogMessage(OutputLog.ERROR, "帳票作成要求不正. " + e);
			e.printStackTrace();
		} 
		return reserveNum;
	}
}