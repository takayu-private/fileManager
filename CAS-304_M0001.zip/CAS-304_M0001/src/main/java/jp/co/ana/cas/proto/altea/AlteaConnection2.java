package jp.co.ana.cas.proto.altea;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class AlteaConnection2 {
	private final static String alteaUrl = "https://nodeA1.test.webservices.amadeus.com/1ASIWGENNH";
	
	public static void main(String[] args) {
		AlteaConnection aConn = new AlteaConnection();
		String reqMsg = aConn.createMsg("123456");
        executePost(reqMsg);
    }
    
    private static void executePost(String reqMsg) {
        System.out.println("===== HTTP POST Start =====");

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
        // もしくは
        // try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
//            HttpPost postMethod = new HttpPost("http://localhost:8081");
        	HttpPost postMethod = new HttpPost(alteaUrl);
            postMethod.addHeader("Content-Type", "text/xml;charset=UTF-8");
            postMethod.addHeader("SOAPAction", "\"http://webservices.amadeus.com/FLIREQ_97_3_1A\"");
//            postMethod.addHeader("Content-Type", "text/xml;charset=UTF-8");

            StringBuilder builder = new StringBuilder();
            builder.append(reqMsg);

            postMethod.setEntity(new StringEntity(builder.toString(),
                                                  StandardCharsets.UTF_8));

            try (CloseableHttpResponse response = httpClient.execute(postMethod)) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    HttpEntity entity = response.getEntity();
                    System.out.println(EntityUtils.toString(entity,
                                                            StandardCharsets.UTF_8));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("===== HTTP POST End =====");
    }
}
