package util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;



/**
 * 予約情報取得クラス.
 * @author 113105A00ACF0
 *
 */
public class ReserveInformation {
	// プロトコル。
	public static final String PROTOCOL = "http";
	// ホストを示すドメイン名。
	public static final String ALTEA_HOST = "localhost";
	// ポート番号。
	public static final int ALTEA_PORT = 8081;
	// ファイルパス。
	public static final String FILE_PATH = "";
	// HTTPメソッド
	public static final String HTTP_METHOD = "POST";

	//Altea情報
	public final String ALTEA_URL = CommonConstant.ALTEA_URL;

	public static final String TAG_SOAP_ENVELOPE = "soapenv:Envelope";
	public static final String TAG_SOAP_BODY = "soapenv:Body";
	public static final String TAG_RESERVE_DETAIL = "reserveDetails";
	public static final String TAG_RESERVE_INFO = "reserveInformation";

	/**
	 * 予約情報取得メイン処理.
	 * @param reserveNum ANA予約番号
	 * @return reserveInfo 予約情報CSVファイルのパス
	 */
	public String getReserveInformation(String reserveNum) {
		String requestMsg = createReserveInformationRequest(reserveNum);
		String reserveInfo = getReserveInformationRequest(requestMsg);
		//		String reserveInfo = responseBody.toString();

		return reserveInfo;
		//		return "";
	}

	/**
	 * SOAPメッセージ作成処理
	 * @param reserveNum
	 * @return
	 */
	public String createReserveInformationRequest(String reserveNum) {
		//SOAPの警告対策
		System.setProperty("javax.xml.soap.SAAJMetaFactory", "com.sun.xml.messaging.saaj.soap.SAAJMetaFactoryImpl");
		HashMap<String, String> userToken = wsSecurity();
		MessageFactory msgFactory = null;
		SOAPMessage requestMsg = null;
		String strMsg = null;
		try {
			Path xmlFile = Paths.get(".\\soap\\Request_Create_Message.xml");
			List<String> strList = Files.lines(xmlFile, StandardCharsets.UTF_8).collect(Collectors.toList());
			String soapTxt = String.join("", strList);
			InputStream soapByte = new ByteArrayInputStream(soapTxt.getBytes());
			msgFactory = MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
			requestMsg = msgFactory.createMessage(null, soapByte);
			SOAPPart soapPart = requestMsg.getSOAPPart();
			SOAPEnvelope env = soapPart.getEnvelope();

			SOAPHeader soapHeader = env.getHeader();
			soapHeader.getElementsByTagName("wsse:Password").item(0).setTextContent(userToken.get("Password"));
			soapHeader.getElementsByTagName("wsse:Nonce").item(0).setTextContent(userToken.get("Nonce"));
			soapHeader.getElementsByTagName("wsu:Created").item(0).setTextContent(userToken.get("Created"));

			ByteArrayOutputStream out = new ByteArrayOutputStream();
			requestMsg.writeTo(out);
			strMsg = new String(out.toByteArray());
			System.out.println(strMsg);
		} catch (Exception e) {
			e.printStackTrace();
		}


		return strMsg;
	}

	public String getReserveInformationRequest(String csvReserveInfo) {
		HttpURLConnection  urlConn = null;
		InputStream in = null;
		BufferedReader reader = null;
		String report = null;

		System.out.println("csvReserveInfo: "+csvReserveInfo);

		try {
			System.out.println("HttpConnect START!!");
			//接続するURLを指定する
			URL url = new URL( PROTOCOL, ALTEA_HOST, ALTEA_PORT, FILE_PATH );
			//コネクションを取得する
			urlConn = (HttpURLConnection) url.openConnection();
			// HTTPメソッドを設定する
			//    urlConn.setRequestMethod("GET");
			urlConn.setRequestMethod(HTTP_METHOD);
			// リスエストとボディ送信を許可する
			urlConn.setDoOutput(true);
			// レスポンスのボディ受信を許可する
			urlConn.setDoInput(true);
			// コネクション接続
			urlConn.connect();
			PrintStream ps = new PrintStream(urlConn.getOutputStream());
			//
			ps.print(csvReserveInfo);
			//System.out.println("connect OK!!");
			int status = urlConn.getResponseCode();
			System.out.println("HTTP status code:" + status);
			OutputLog.outputLogMessage(OutputLog.DEBUG, "Altea HTTP status code:" + status);
			//			String headerKey = null;
			//			int counter = 0;
			// レスポンスのHTTP header取得
			//			while ((headerKey = urlConn.getHeaderFieldKey(++counter)) != null) {
			//				System.out.println(headerKey + ": "+ urlConn.getHeaderField(counter));
			//			}

			if(status == HttpURLConnection.HTTP_OK) {

				in = urlConn.getInputStream();
				reader = new BufferedReader(new InputStreamReader(in));
				StringBuilder sb = new StringBuilder();
				String line;
				// レスポンスのHTTP body取得
				while ((line = reader.readLine()) != null) {
					sb.append(line);
				}
				report = sb.toString();
				System.out.println("body部: "+report);
				OutputLog.outputLogMessage(OutputLog.DEBUG, "Altea HTTP body:" + report);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Altea IO ERROR. " + e);
			OutputLog.outputLogMessage(OutputLog.ERROR, "Altea IO ERROR. " + e);
		} finally {


			try {
				if(reader!=null) {
					reader.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		urlConn.disconnect();



		String soapenvEnvelope = extractValue(report,TAG_SOAP_ENVELOPE);
		String soapenvBod = extractValue(soapenvEnvelope, TAG_SOAP_BODY);
		String reserveDetails = extractValue(soapenvBod, TAG_RESERVE_DETAIL);
		String reseveInfo = extractValue(reserveDetails, TAG_RESERVE_INFO);
		return reseveInfo;
	}


	public String extractValue(String xmlData, String tag) {
		if(xmlData == null ) {
			return null;
		}
		else if(tag == null) {
			return xmlData;
		}
		int startIndex = xmlData.indexOf("<"+tag) ;
		int endIndex = xmlData.indexOf("</"+tag+">") ;

		String tagValue = null;
		try {
			startIndex = xmlData.indexOf(">",startIndex);
		    tagValue =xmlData.substring(startIndex+1, endIndex) ;
		System.out.println("tagValue: "+tagValue);
		}
		catch(Exception ex) {
			return xmlData;
		}
		return tagValue;
	}

	public HashMap<String, String> wsSecurity() {
		HashMap<String, String> wsSecurity = new HashMap<String, String>();
		//Created
		Calendar cal = Calendar.getInstance();
		long timeZone = cal.getTimeInMillis();
		String created = createCreated(timeZone);
		String createdHex = createCreatedHex(created);
		wsSecurity.put("Created", created);
		//Nonce
		String noceHex = createNonceHex(timeZone);
		String nonce = createNonce(noceHex);
		wsSecurity.put("Nonce", nonce);
		//password
		String passwdSha = createPasswdSha();
		String passwd = createPasswd(noceHex, createdHex, passwdSha);
		wsSecurity.put("Password", passwd);

		return wsSecurity;
	}

	/**
	 * Created作成メソッド.
	 * @param currentTime
	 * @return
	 */
	public String createCreated(long currentTime) {
		SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		timeFormat.setTimeZone(TimeZone.getTimeZone("Zulu"));
		Date curDate = new Date(currentTime);
		String created = timeFormat.format(curDate.getTime());

		return created;
	}

	/**
	 * CreatedのHex変換メソッド.
	 * @param created
	 * @return
	 */
	public String createCreatedHex(String created) {
		//パスワード生成用にCreatedをHEX変換
		byte[] createByte = created.getBytes();
		String createdHex = String.format("%040x", new BigInteger(1, createByte));
		String createdTest = "323032302d30332d31365430383a31383a31312e3032395a";
		if (createdHex.equals(createdTest)) {
			System.out.println("Created OK");
		} else {
			System.out.println("Created NG");
			System.out.println("作=" + createdHex);
			System.out.println("正=" + createdTest);
		}

		return createdHex;
	}

	public String createNonceHex(long currentTime) {
		//Nonce
		String nonceHex = "";
		try {
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
			//Seed値設定
			random.setSeed(currentTime);
			byte[] resultValue = new byte[16];
			//パスワード生成用にNonceをHEX変換
			random.nextBytes(resultValue);
			nonceHex = String.format("%040x", new BigInteger(1, resultValue));
//			nonceHextest = "4EA34B4CAA5294AAEBF9659B8217BE8C";
			nonceHex = nonceHex.toLowerCase();
			nonceHex = nonceHex.replaceFirst("^0+", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		String nonceHextest = "4EA34B4CAA5294AAEBF9659B8217BE8C";
		if(nonceHex.equals(nonceHextest)) {
			System.out.println("nonceHex OK");
		} else {
			System.out.println("nonceHex NG");
			System.out.println("作=" + nonceHex);
			System.out.println("正=" + nonceHextest);
		}
		return nonceHex;
	}

	public String createNonce(String nonceHex) {
		byte[] nonceByte = null;
		char[] nonceHexstr = nonceHex.toCharArray();
		byte[] decodedHex;
		try {
			decodedHex = Hex.decodeHex(nonceHexstr);
			//NonceをBase64にエンコード
			nonceByte = Base64.encodeBase64(decodedHex);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String nonce = "";
		if(nonceByte!=null) {
		for(byte b : nonceByte) {
			nonce = nonce + (char)b;
		}
		}
		String nonceTest = "x+0zeuR+nTHifxVGmY7hIA==";
//		String nonceTest = "TqNLTKpSlKrr+WWbghe+jA==";
		if (nonce.equals(nonceTest)) {
			System.out.println("Nonce OK");
		} else {
			System.out.println("Nonce NG");
			System.out.println("作=" + nonce);
			System.out.println("正=" + nonceTest);
		}
		return nonce;
	}

	public String createPasswdSha() {
		//password
		String hex = "";
		MessageDigest sha = null;
		try {
			//パスワードのHex変換
			byte[] passwdByte = CommonConstant.ALTEA_PASSWD.getBytes();
			hex = String.format("%040x", new BigInteger(1, passwdByte));
			//Hex(パスワード)のsha-1変換
			sha = MessageDigest.getInstance("SHA-1");
			sha.reset();
			sha.update(CommonConstant.ALTEA_PASSWD.getBytes());

			String passHexTest = "324a5362306a584e";
			if(hex.replaceFirst("^0+", "").equals(passHexTest)) {
				System.out.println("PasswordHex OK");
			} else {
				System.out.println("PasswordHex NG");
				System.out.println("作=" + hex.replaceFirst("^0+", ""));
				System.out.println("正=" + passHexTest);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		//Sha-1(Hex(パスワード))を文字列化
		String passwdSha = String.format("%040x", new BigInteger(1, sha.digest()));
		String passShaTest = "4243f3ff732f14a562aca4cb6d837cc05726055d";
		if(passwdSha.equals(passShaTest)) {
			System.out.println("PasswordSha OK");
		} else {
			System.out.println("PasswordSha NG");
			System.out.println("作=" + passwdSha);
			System.out.println("正=" + passShaTest);
		}
		return passwdSha;
	}

	public String createPasswd(String nonceHex, String createdHex, String passwdSha) {
		byte[] passwdDigest = null;
		MessageDigest sha = null;
		String passwdHex = null;
		//Nonce + Created + Password
		String hex = nonceHex + createdHex + passwdSha;
		System.out.println("hex= " + hex);
		try {
			//Sha1(Nonce + Created + Password)
			char[] passShaChar = hex.toCharArray();
			byte[] decodedShaHex = Hex.decodeHex(passShaChar);
			sha = MessageDigest.getInstance("SHA-1");
			sha.reset();
			sha.update(decodedShaHex);
			//Hex(Sha1(Nonce + Created + Password))
			passwdHex = String.format("%040x", new BigInteger(1, sha.digest()));
			//Hex(Sha1(Nonce + Created + Password))をBase64変換
			char[] passHexCha = passwdHex.toCharArray();
			byte[] decodedHex = Hex.decodeHex(passHexCha);
			passwdDigest = Base64.encodeBase64(decodedHex);
		} catch (DecoderException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		String passwd = "";
		if(passwdDigest!=null) {
		for(byte b : passwdDigest) {
			passwd = passwd + (char)b;
		}
		}
		String hexTest = "C3160D7F0030A1A71194DF29D2DBB16D38620DE0";
		hexTest = hexTest.toLowerCase();
		if(passwdHex.equals(hexTest)) {
			System.out.println("passwdHex OK");
		} else {
			System.out.println("passwdHex NG");
			System.out.println("作=" + passwdHex);
			System.out.println("正=" + hexTest);
		}
		String passTest = "wxYNfwAwoacRlN8p0tuxbThiDeA=";
		if(passwd.equals(passTest)) {
			System.out.println("Password OK");
		} else {
			System.out.println("Password NG");
			System.out.println("作=" + passwd);
			System.out.println("正=" + passTest);
		}

		return passwd;

	}
}