package jp.co.ana.cas.proto.groovy

import org.apache.ws.security.util.Base64;
import java.security.SecureRandom;
def generate_nonce() {	
	def random = SecureRandom.getInstance("SHA1PRNG");
	random.setSeed(System.currentTimeMillis());
	def nonceValue = new byte[16];
	random.nextBytes(nonceValue);
	return Base64.encode(nonceValue);
}
return generate_nonce()