package jp.co.ana.cas.proto.groovy

import java.text.SimpleDateFormat;

def generate_created() {
	def format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	def cal = Calendar.instance;
	format.setTimeZone(TimeZone.getTimeZone("Zulu"));
	return format.format(cal.time);
}
return generate_created()