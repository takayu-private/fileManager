# BlankProject
サービスのひな形となる空プロジェクトです。各サービスはこれをベースにして自サービスのひな形を作成します。

# 利用手順  

## 各サービスのひな形作成（実装担当者のうち、チーム代表者が実施）   

各サービスの開発を開始するときに、担当チームの誰かひとりが実行します。  
各サービスは原則として開発チームの責任で管理することになりますが、ブランクプロジェクトの更新と同期を保てるようにするため、Gitの機能を用いてコピーします。

1. GitHubの「Repositories」 > 「New」 で個々のプロジェクトを管理するための空リポジトリを作成する  
2. Git Bashを開き、このリポジトリのベアクローン[^1](更新情報のみを格納したローカルリポジトリを作成する操作。通常のローカルリポジトリとは異なり、ディレクトリ名に「.git」がつく。)を作成する

  ```
  git clone --bare https://github.com/CAS-prototype/BlankProject.git
  ```

3. 2でできたベアクローンのディレクトリ(BlankProject.git)に移動する

  ```
  cd BlankProject.git
  ```

4. 1で作ったリポジトリに、カレントディレクトリの内容をミラープッシュする
  ```
  git push --mirror 1で作った空リポジトリのHTTPS URL
  ```

5. 2で作ったベアクローンを削除する
  ```
  cd .. 
  rm -rf BlankProject.git
  ```

6. Gradleプロジェクト名をリネームする  
  - settings.gradleのrootProject.nameを適切なものに変更
  - Gradleのディレクトリ名を適切なものに変更

7. 6の変更をコミット、プッシュする

## ブランクプロジェクトの変更を取り込む手順  

ここでは、各サービスのリモートリポジトリ(origin)に対し、ブランクプロジェクトのリモートリポジトリ名を"blank-project"とします。

1. リモートリポジトリに、ブランクプロジェクトのリポジトリを追加する  
  - Git Bashから行う場合
    ```
    cd 各サービスのローカルリポジトリ
    git remote add blank-project https://github.com/CAS-prototype/BlankProject.git
    ```
- Eclipse(Egit)から行う場合
    1. Git RepositoriesビューのRemotesから「Create Remote...」を選択
    2. 名前にblank-projectを入力、「Configure fetch」を指定し、次ページで、ブランクプロジェクトのリポジトリURLを指定

2. blank-project/masterの変更内容をフェッチする

3. `git log blank-project` で、取り込むコミットのハッシュ値を確認

4. ローカルリポジトリに未コミットの変更がない状態にする

5. cherry-pickなどで、blank-project/masterへのコミットをローカルリポジトリに取り込む
  ```
  git cherry-pick <1.のハッシュ値>
  ```

  - コンフリクトする場合は、マージツールを使って解決する
  - 未コミットの変更がある状態でcherry-pickをするとうまくいかないので、一度`git cherry-pick --abort`で抜け、未コミットファイルがないようにする

6. 取り込んだ変更をgit commitでコミットする

## 開発手順（実装担当者が実施）

開発に必要な各種操作の手順を記載する。
（Gitの使用方法など、ごく基本的な部分については割愛する。）

### IDEへの取り込み  

#### Eclipse

1. 自サービス用のリポジトリをあらかじめクローンしておく(Eclipseの機能(Egit)でもCLIでもよい)
2. Package Explorerから、Import > Gradle > Existing Gradle Projectで、ローカルリポジトリ上のディレクトリを指定  
  Gitの機能でひな形プロジェクトをImportすると、EclipseのGradle機能で認識させるのに手間がかかるため、Gradle Projectとしてインポートする  

#### VSCode

T.B.D.

### APIテンプレートコード作成&修正

外部設計書のAPI仕様からOpenAPI Generatorを使ってテンプレートコードを作成および修正する手順を記載する。

- 設計書リポジトリから開発対象サービスの外部設計書を取得する。

- コンソール上で、カレントディレクトリをopenapi-generator-cli-4.3.x.jarの配置ディレクトリにした状態で、以下のコマンドを実行する。
  - API仕様を記載したYamlファイルへのパスを`$PATH_TO_SPECIFICATION`、アプリケーションのルートパッケージ名を`$PACKAGE_NAME`とする。）
  
  `java -jar openapi-generator-cli-4.3.x.jar generate -i $PATH_TO_SPECIFICATION -g spring -o out --api-package $PACKAGE_NAME.api --model-package $PACKAGE_NAME.model`

- `out/src/main/$PACKAGE_NAME` ディレクトリ以下に生成されたコードを、開発プロジェクトの同名ディレクリにコピーする。（その他のディレクトリに生成されたコードは、共通部品として最初に作成されているので無視する。）
  - api
  - model

- `out/src/main/$PACKAGE_NAME/api/~Api.java`に実装されているgetRequestメソッド以外の全メソッドについて、`out/src/main/$PACKAGE_NAME/api/~ApiController.java`でオーバーライドして正しい業務処理を記載する。
  - 具体的な業務処理の内容は、内部設計書を参照すること。

### 単体テスト実行

- プロジェクトのルートディレクトリで`gradlew test`を実行する。

### アプリケーション実行

- プロジェクトのルートディレクトリで`gradlew bootRun`を実行する。
