package com.zararsiddiqi.demo.furnitureui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FurnitureUiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FurnitureUiApplication.class, args);
    }

}
