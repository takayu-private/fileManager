package com.zararsiddiqi.demo.furnitureservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FurnitureServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FurnitureServiceApplication.class, args);
    }

}
